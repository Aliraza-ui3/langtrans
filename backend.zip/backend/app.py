from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import numpy as np
import cv2
import mediapipe as mp
import tensorflow as tf
from io import BytesIO
from PIL import Image
import logging
from contextlib import asynccontextmanager
import uvicorn
import os
import json
from datetime import datetime
from typing import List, Dict, Any
from pyngrok import ngrok
import nest_asyncio

# Suppress TensorFlow info and warning messages
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# --- ASL Text Prediction Model Configuration ---
ASL_MODEL_PATH = 'model/model.tflite'
ASL_LABELS_PATH = 'model/hybrid_label_classes.npy'
RESULTS_FILE = 'detection_records.json'

NGROK_AUTH_TOKEN = "2wKPlPImK4ZeH2kw3G5BxyCSAsz_5T1GQicwptHdtS1ja5xFU"
PORT = 8000

# Initialize detection records list
detection_records = []

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=True,
    max_num_hands=2,
    min_detection_confidence=0.5
)

# Initialize Ngrok only if the token is provided
def start_ngrok():
    if NGROK_AUTH_TOKEN:
        try:
            ngrok.set_auth_token(NGROK_AUTH_TOKEN)
            tunnel = ngrok.connect(PORT, bind_tls=True)
            public_url = tunnel.public_url
            print(f"\n\nNgrok Public URL: {public_url}\n")
            return public_url
        except Exception as e:
            print(f"⚠️ Ngrok failed to start: {str(e)}")
            return None
    return None

# Lifespan handler for TFLite models
@asynccontextmanager
async def lifespan(app: FastAPI):
    public_url = start_ngrok()  # This will attempt to start ngrok
    
    try:
        # Load ASL model
        global asl_interpreter, asl_label_map
        asl_interpreter = tf.lite.Interpreter(model_path=ASL_MODEL_PATH)
        asl_interpreter.allocate_tensors()
        
        # Load label map
        asl_label_map = np.load(ASL_LABELS_PATH, allow_pickle=True)
        
        logging.info("✅ All models loaded successfully")
    except Exception as e:
        logging.error(f"❌ Error loading models: {e}")
        raise
    
    yield
    
    # Cleanup on shutdown
    save_records_to_json()
    del asl_interpreter
    hands.close()
    if NGROK_AUTH_TOKEN:
        ngrok.kill() 



def detect_hand_landmarks(image: np.ndarray) -> Dict[str, Any]:
    """Detect hand landmarks using MediaPipe (returns only x,y coordinates)."""
    try:
        # Convert to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Process the image
        results = hands.process(image_rgb)
        
        # Prepare output
        output = {
            "hands_detected": False,
            "landmarks": [],  # This will now contain only x,y coordinates
            "bounding_boxes": []
        }
        
        if results.multi_hand_landmarks:
            output["hands_detected"] = True
            
            for hand_landmarks in results.multi_hand_landmarks:
                # Extract only x,y coordinates
                landmarks = []
                for landmark in hand_landmarks.landmark:
                    landmarks.append({
                        "x": landmark.x,
                        "y": landmark.y
                        # z coordinate is intentionally omitted
                    })
                output["landmarks"].append(landmarks)
                
                # Calculate bounding box (using only x,y)
                x_coords = [lm.x for lm in hand_landmarks.landmark]
                y_coords = [lm.y for lm in hand_landmarks.landmark]
                x_min, x_max = min(x_coords), max(x_coords)
                y_min, y_max = min(y_coords), max(y_coords)
                
                output["bounding_boxes"].append({
                    "x_min": x_min,
                    "y_min": y_min,
                    "x_max": x_max,
                    "y_max": y_max
                })
                
        return output
        
    except Exception as e:
        logging.error(f"Error in hand landmark detection: {e}")
        return {
            "hands_detected": False,
            "landmarks": [],
            "bounding_boxes": [],
            "error": str(e)
        }
    
def save_records_to_json():
    """Save all detection records to JSON file."""
    try:
        with open(RESULTS_FILE, 'w') as f:
            json.dump(detection_records, f, indent=2)
        logging.info(f"✅ Detection records saved to {RESULTS_FILE}")
    except Exception as e:
        logging.error(f"❌ Error saving records: {e}")


app = FastAPI(lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def process_image(image_data: bytes) -> np.ndarray:
    """Convert uploaded image to BGR numpy array."""
    image = Image.open(BytesIO(image_data))
    image = np.array(image)
    return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

def predict_asl_text(landmarks: List[Dict[str, float]]) -> str:
    """Predict ASL text label from hand landmarks using TFLite model."""
    try:
        # Prepare input tensor
        input_details = asl_interpreter.get_input_details()
        output_details = asl_interpreter.get_output_details()
        
        # Extract and normalize landmarks
        x_vals = [lm['x'] for lm in landmarks]
        y_vals = [lm['y'] for lm in landmarks]
        min_x, min_y = min(x_vals), min(y_vals)
        
        norm_x = [(x - min_x) for x in x_vals]
        norm_y = [(y - min_y) for y in y_vals]
        
        features = np.array(norm_x + norm_y, dtype=np.float32).reshape(1, -1)
        
        # Run inference
        asl_interpreter.set_tensor(input_details[0]['index'], features)
        asl_interpreter.invoke()
        probs = asl_interpreter.get_tensor(output_details[0]['index'])
        
        pred_idx = int(np.argmax(probs))
        return str(asl_label_map[pred_idx])
        
    except Exception as e:
        logging.error(f"Error in ASL prediction: {e}")
        return "Unknown"

@app.post("/detect")
async def detect_hand(file: UploadFile = File(...)):
    try:
        # Process image
        image_data = await file.read()
        image = process_image(image_data)
        
        # Detect hand landmarks
        detection_result = detect_hand_landmarks(image)
        
        if not detection_result["hands_detected"]:
            response = {
                "success": False,
                "message": "No hands detected in the image",
                "landmarks": []  # Return empty landmarks array
            }
            print("Response:", response)  # Print the response
            return response
        
        # For each detected hand, predict ASL text
        predictions = []
        for i, landmarks in enumerate(detection_result["landmarks"]):
            predicted_text = predict_asl_text(landmarks)
            predictions.append({
                "hand_index": i,
                "predicted_text": predicted_text,
                "bounding_box": detection_result["bounding_boxes"][i]
            })
        
        # Create record
        record = {
            "timestamp": datetime.now().isoformat(),
            "predictions": predictions,
            "image_size": {
                "width": image.shape[1],
                "height": image.shape[0]
            },
            "landmarks": detection_result["landmarks"]  # Save landmarks in record
        }
        
        # Add to records
        detection_records.append(record)
        print(f"Detection record added: {record}")
        
        response = {
            "success": True,
            "predicted_text": predictions,
            "num_hands_detected": len(predictions),
            "landmarks": detection_result["landmarks"],  # Include all landmarks in response
            "bounding_boxes": detection_result["bounding_boxes"]  # Include all bounding boxes
        }
        print("Response:", response)  # Print the response
        return response
        
    except Exception as e:
        logging.error(f"Error during detection: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    

if __name__ == "__main__":
    try:
        nest_asyncio.apply()
        print("Starting server...")
        uvicorn.run(app, host="0.0.0.0", port=PORT)
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    except Exception as e:
        print(f"Server error: {str(e)}")
    finally:
        save_records_to_json()