from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import numpy as np
import cv2
import tensorflow as tf
from io import BytesIO
from PIL import Image
import logging
from contextlib import asynccontextmanager
from pyngrok import ngrok
import nest_asyncio
import uvicorn
import os
import json
from datetime import datetime


# Suppress TensorFlow info and warning messages
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# --- ASL Text Prediction Model Configuration ---
ASL_MODEL_PATH = 'model/asl_nn_model-updated_new.tflite'
ASL_LABELS_PATH = 'model/hybrid_label_classes.npy'
RESULTS_FILE = 'detection_records.json'

# Ngrok Configuration
NGROK_AUTH_TOKEN = "2wKPlPImK4ZeH2kw3G5BxyCSAsz_5T1GQicwptHdtS1ja5xFU"
PORT = 8000

# Initialize detection records list
detection_records = []

def save_records_to_json():
    """Save all detection records to JSON file."""
    try:
        with open(RESULTS_FILE, 'w') as f:
            json.dump(detection_records, f, indent=2)
        logging.info(f"✅ Detection records saved to {RESULTS_FILE}")
    except Exception as e:
        logging.error(f"❌ Error saving records: {e}")

# Initialize Ngrok Tunnel
def start_ngrok():
    ngrok.set_auth_token(NGROK_AUTH_TOKEN)
    tunnel = ngrok.connect(PORT, bind_tls=True)
    public_url = tunnel.public_url
    print(f"\n\nNgrok Public URL: {public_url}\n")
    return public_url

# Lifespan handler for TFLite models
@asynccontextmanager
async def lifespan(app: FastAPI):
    public_url = start_ngrok()
    global palm_interpreter, landmark_interpreter, asl_interpreter, asl_label_map
    
    try:
        # Load all TFLite models
        palm_interpreter = tf.lite.Interpreter(model_path='model/palm_detection_lite.tflite')
        palm_interpreter.allocate_tensors()
        
        landmark_interpreter = tf.lite.Interpreter(model_path='model/hand_landmark_full.tflite')
        landmark_interpreter.allocate_tensors()
        
        asl_interpreter = tf.lite.Interpreter(model_path=ASL_MODEL_PATH)
        asl_interpreter.allocate_tensors()
        
        # Load label map
        asl_label_map = np.load(ASL_LABELS_PATH, allow_pickle=True)
        
        logging.info("✅ All models loaded successfully")
    except Exception as e:
        logging.error(f"❌ Error loading models: {e}")
        raise
    
    yield
    
    # Cleanup on shutdown
    save_records_to_json()  # Save records before shutdown
    del palm_interpreter
    del landmark_interpreter
    del asl_interpreter
    ngrok.kill()

app = FastAPI(lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def process_image(image_data: bytes) -> np.ndarray:
    """Convert uploaded image to BGR numpy array."""
    image = Image.open(BytesIO(image_data))
    image = np.array(image)
    return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

def detect_palm(image: np.ndarray) -> dict:
    """Run palm detection TFLite model."""
    resized = cv2.resize(image, (192, 192))
    normalized = resized.astype('float32') / 255.0
    inp = np.expand_dims(normalized, axis=0)
    
    inp_details = palm_interpreter.get_input_details()
    out_details = palm_interpreter.get_output_details()
    
    palm_interpreter.set_tensor(inp_details[0]['index'], inp)
    palm_interpreter.invoke()
    
    preds = palm_interpreter.get_tensor(out_details[0]['index'])
    
    best_score = 0.0
    best_box = [0, 0, 1, 1]
    
    for i in range(preds.shape[1]):
        score = preds[0, i, 0]
        if score > best_score:
            best_score = float(score)
            x_min, y_min, x_max, y_max = preds[0, i, 1:5]
            x_min, y_min, x_max, y_max = [max(0.0, min(1.0, v)) for v in (x_min, y_min, x_max, y_max)]
            if x_max > x_min and y_max > y_min:
                best_box = [x_min, y_min, x_max, y_max]
    
    return {"detected": best_score > 0.5, "bounding_box": best_box, "score": best_score}

def detect_landmarks(cropped: np.ndarray) -> list:
    """Run hand landmark TFLite model."""
    resized = cv2.resize(cropped, (224, 224))
    normalized = resized.astype('float32') / 255.0
    inp = np.expand_dims(normalized, axis=0)
    
    inp_details = landmark_interpreter.get_input_details()
    out_details = landmark_interpreter.get_output_details()
    
    landmark_interpreter.set_tensor(inp_details[0]['index'], inp)
    landmark_interpreter.invoke()
    
    lm = landmark_interpreter.get_tensor(out_details[0]['index'])
    return lm[0].reshape(-1).tolist()

def predict_asl_text(landmarks: list) -> str:
    """Predict ASL text label from hand landmarks using TFLite model."""
    # Prepare input tensor
    input_details = asl_interpreter.get_input_details()
    output_details = asl_interpreter.get_output_details()
    
    # Extract and normalize landmarks
    coords = np.array(landmarks)
    x_vals = coords[0::3]
    y_vals = coords[1::3]
    min_x, min_y = x_vals.min(), y_vals.min()
    norm_x = (x_vals - min_x).tolist()
    norm_y = (y_vals - min_y).tolist()
    features = np.array(norm_x + norm_y, dtype=np.float32).reshape(1, -1)
    
    # Run inference
    asl_interpreter.set_tensor(input_details[0]['index'], features)
    asl_interpreter.invoke()
    probs = asl_interpreter.get_tensor(output_details[0]['index'])
    
    pred_idx = int(np.argmax(probs))
    return str(asl_label_map[pred_idx])

@app.post("/detect")
async def detect_hand(file: UploadFile = File(...)):
    try:
        # Process image
        image_data = await file.read()
        image = process_image(image_data)
        
        # Detect palm
        palm_res = detect_palm(image)
        if not palm_res["detected"]:
            return {"success": False, "message": "No hand detected"}
        
        # Calculate bounding box
        h, w = image.shape[:2]
        x_min = int(palm_res["bounding_box"][0] * w)
        y_min = int(palm_res["bounding_box"][1] * h)
        x_max = int(palm_res["bounding_box"][2] * w)
        y_max = int(palm_res["bounding_box"][3] * h)
        
        # Validate bounding box
        x_min, x_max = sorted((max(0, x_min), min(w-1, x_max)))
        y_min, y_max = sorted((max(0, y_min), min(h-1, y_max)))
        if x_max <= x_min or y_max <= y_min:
            return {"success": False, "message": "Invalid hand region"}
        
        # Crop and detect landmarks
        crop = image[y_min:y_max, x_min:x_max]
        landmarks = detect_landmarks(crop)
        print(f"Landmarks: {landmarks}")
        
        # Predict ASL text
        predicted_text = predict_asl_text(landmarks)
        print(f"Predicted ASL Text: {predicted_text}")
        
        # Create record
        record = {
            "timestamp": datetime.now().isoformat(),
            "predicted_text": predicted_text,
            "landmarks": landmarks,
            "bounding_box": palm_res["bounding_box"],
            "score": palm_res["score"]
        }
        
        # Add to records
        detection_records.append(record)
        
        return {
            "success": True,
            "landmarks": landmarks,
            "bounding_box": palm_res["bounding_box"],
            "predicted_text": predicted_text
        }
        
    except Exception as e:
        logging.error(f"Error during detection: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    try:
        nest_asyncio.apply()
        uvicorn.run(app, host="0.0.0.0", port=PORT)
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    finally:
        save_records_to_json()  # Ensure records are saved even on crash